﻿using Microsoft.ML;

// Tworzymy kontekt MachineLearning'u
MLContext mLContext = new MLContext();

// Wczytanie danych z pliku
string dataPath = "filmy.csv";
IDataView dataView = mLContext.Data.LoadFromTextFile<Film>(
    path: dataPath,
    hasHeader: true,
    separatorChar: ','
);
// Stworzenie pipeline:
// Czyli stworzenie łańcucha kroków
var pipeline = mLContext.Transforms.Categorical
            .OneHotEncoding(
                inputColumnName: "Gatunek",
                outputColumnName: "GatunekEncoded"
            )
            .Append(mLContext.Transforms.Categorical.OneHotEncoding(
                inputColumnName: "Rezyser",
                outputColumnName: "RezyserEncoded"
            ))
            .Append(mLContext.Transforms.Concatenate(
                "Features", // Kolumna, która będzie przechowywać poniższe cechy (kolumny)
                "GatunekEncoded",
                "RezyserEncoded",
                nameof(Film.Rok),
                nameof(Film.Ocena)
            ))
            .Append(mLContext.BinaryClassification.Trainers.SdcaLogisticRegression(
                labelColumnName: nameof(Film.Lubiany),
                featureColumnName: "Features"
            ));

// Trenujemy nasz model po krokach z pipleline'u na podstawie załadowanych danych do dataView
var model = pipeline.Fit(dataView);


// Zapisujemy model np. do pliku
mLContext.Model.Save(model, dataView.Schema, "ModelFilmy.zip");

Console.WriteLine("Model wytrenowany");

// Tworzymy silnik predykcji (PredictionEngine)
var predEngine = mLContext.Model.CreatePredictionEngine<Film, FilmPrediction>(model);

var nowyFilm = new Film()
{
    Tytul = "Harry Potter",
    Gatunek = "Horror",
    Rok = 2012,
    Ocena = 9.1f,
    Rezyser = "Nolan"
};

var wynik = predEngine.Predict(nowyFilm);

Console.WriteLine($"Czy film '{nowyFilm.Tytul}' będzie lubiany? {wynik.Prediction} (Score {wynik.Score})");
